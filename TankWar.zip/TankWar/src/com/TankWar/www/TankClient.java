package com.TankWar.www;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * �����̹����Ϸ��������
 * @author �
 *
 */
@SuppressWarnings("serial")
public class TankClient extends Frame {
	/**
	 * ����̹����Ϸ�Ŀ��ȣ��߶�
	 */
	public static final int GAME_WIDTH = 800;
	public static final int GAME_HEIGHT = 600;
	Tank myTank = new Tank(400, 300, true, Tank.Direction.STOP, this);
	Wall w1 = new Wall(300, 100, 200, 40, this);
	Wall w2 = new Wall(100, 250, 40, 300, this);
	Image offScreamImage = null;
	Blood b = new Blood();
/**
 * ̹����Ϸ�ı�ը���ӵ����з�̹������
 */
	List<Explode> explodes = new ArrayList<Explode>();
	List<Missile> missiles = new ArrayList<Missile>();
	List<Tank> tanks = new ArrayList<Tank>();
/**
 * �����ػ�
 */
	public void paint(Graphics g) {
		Color c = g.getColor();
		g.setColor(Color.white);
		/*
		 * ָ���ӵ�����ը��̹�˵�����
		 * �Լ�̹�˵�����ֵ
		 */
		g.drawString("missiles count	" + missiles.size(), 10, 50);
		g.drawString("explodes count	" + explodes.size(), 10, 70);
		g.drawString("enemytanks count	" + tanks.size(), 10, 90);
		g.drawString("mytank  life	" + myTank.getLife(), 10, 110);
		if (tanks.size() <= 0) {
			for (int i = 0; i < 5; i++) {
				tanks.add(new Tank(50 + 40 * (i + 1), 50, false,
						Tank.Direction.D, this));
			}
		}
		for (int i = 0; i < missiles.size(); i++) {
			Missile m = missiles.get(i);
			m.hitTanks(tanks);
			m.hitTank(myTank);
			m.hitWall(w1);
			m.hitWall(w2);
			m.draw(g);
		}
		for (int i = 0; i < explodes.size(); i++) {
			Explode e = explodes.get(i);
			e.draw(g);
		}
		for (int i = 0; i < tanks.size(); i++) {
			Tank t = tanks.get(i);
			t.TankWithWall(w1);
			t.TankWithWall(w2);
			t.TankWithTank(tanks);
			t.draw(g);
		}
		myTank.draw(g);
		myTank.eat(b);
		w1.draw(g);
		w2.draw(g);
		b.draw(g);
		g.setColor(c);
	}
/**
 * ��дUpdata����
 */
	public void update(Graphics g) {
		if (offScreamImage == null) {
			offScreamImage = this.createImage(GAME_WIDTH, GAME_HEIGHT);
		}
		Graphics goffScream = offScreamImage.getGraphics();
		Color c = goffScream.getColor();
		goffScream.setColor(Color.gray);
		goffScream.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
		goffScream.setColor(c);
		paint(goffScream);
		g.drawImage(offScreamImage, 0, 0, null);
	}
/**
 * ��������ʾ̹��������
 */
	public void lauchFrame() {
		for (int i = 0; i < 10; i++) {
			tanks.add(new Tank(50 + 40 * (i + 1), 50, false, Tank.Direction.D,
					this));
		}
		this.setLocation(200, 70);
		this.setSize(GAME_WIDTH, GAME_HEIGHT);
		this.setTitle("̹�˴�ս");
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		this.setBackground(Color.black);// ����ɫΪ��ɫ
		this.setResizable(false);
		this.addKeyListener(new KeyMonitor());
		setVisible(true);
		new Thread(new PaintThread()).start();
	}
// main����
	public static void main(String[] args) {
		TankClient tc = new TankClient();
		tc.lauchFrame();
	}

	// ������һ���߳�
	private class PaintThread implements Runnable {

		public void run() {
			while (true) {
				repaint();
				try {
					Thread.sleep(40);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
	}
/**
 * 
 * �ڲ��� ���Ӽ��̼���
 *
 */
	private class KeyMonitor extends KeyAdapter {
		public void keyReleased(KeyEvent e) {
			myTank.keyReleased(e);
		}

		public void keyPressed(KeyEvent e) {
			myTank.keyPressed(e);
		}

	}
}
